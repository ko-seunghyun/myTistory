﻿using MIMER.RFC2633;
using NUnit.Framework;

namespace MIMERTests.RFC2633
{
    [TestFixture]
    public class SMIMETypeFieldTests
    {
        [Test]
        public void TestSMIMTypeProperty()
        {
            //SMIMETypeField field = new SMIMETypeField();
        }
    }
}
