MIMER
=====

.NET Mime parser library
