﻿

namespace MIMER
{
    public interface ICompiledPattern:IPattern
    {
        void Compile();
    }
}
